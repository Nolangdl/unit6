import csv

pressures = []
num_of_lines_to_process = 1000
biggestNumber = 0
smallestNumber = 1500
with open('pressure_partial.csv') as csv_file:
    csv_reader = csv.reader(csv_file, delimiter=',')
    line_count = 0
    for row in csv_reader:
        if line_count == 0:
            print(f'Column names are {", ".join(row)}')
            line_count += 1
            
        else:
          #Set biggest number to the first row of data
          if(line_count == 1):
            biggestNumber = float(row[1])
            

          print(f'Pressure: \t{row[1]}')
          pressures.append([row[1],row[3]])
          #If the current value of the data is bigger than the previous biggestNumber, set biggestNumber equal to the new data value.
          if(biggestNumber<float(row[1])):
            biggestNumber = float(row[1])
          if(smallestNumber>float(row[1])):
            smallestNumber = float(row[1])

          line_count += 1
          if(line_count > num_of_lines_to_process):
            break
    print(f'Processed {line_count} lines.')
print(len(pressures))






temperature = []
num_of_lines_to_process = 1000
biggestNumberTemp = 0
smallestNumberTemp = 100
with open('temperature_full.csv') as csv_file:
    csv_reader = csv.reader(csv_file, delimiter=',')
    line_count = 0
    for row in csv_reader:
        if line_count == 0:
            print(f'Column names are {", ".join(row)}')
            line_count += 1
            
        else:
          #Set biggest number to the first row of data
          if(line_count == 1):
            biggestNumberTemp = float(row[1])
            

          print(f'Pressure: \t{row[1]}')
          temperature.append([row[1],row[3]])
          #If the current value of the data is bigger than the previous biggestNumber, set biggestNumber equal to the new data value.
          if(biggestNumberTemp<float(row[1])):
            biggestNumberTemp = float(row[1])
          if(smallestNumberTemp>float(row[1])):
            smallestNumberTemp = float(row[1])

          line_count += 1
          if(line_count > num_of_lines_to_process):
            break
    print(f'Processed {line_count} lines.')
print(len(temperature))
print(smallestNumberTemp)
print(biggestNumberTemp)
print(smallestNumber)
print(biggestNumber)
print(f'pressure is {pressures[0][0]} at {pressures[0][1]}' )
print(f'pressure is {temperature[0][0]} at {temperature[0][1]}' )